"""
Comprehensive Experiment: 8 training conditions
- Loss: NLL vs MMD
- Scheduler: Cosine vs FFF
- Mode: Teacher Forcing vs Autoregressive

runs/model/3/1113/
"""

import os
os.environ['JAX_PLATFORMS'] = 'cuda'

import json
import numpy as np
import pandas as pd
import jax
import jax.numpy as jnp
from jax import random, lax
from pathlib import Path
from tqdm import tqdm
from functools import partial
import pickle
import matplotlib.pyplot as plt

# Import HQRNN modules
from hqrnn.config.base import Config, ExperimentConfig
from hqrnn.quantum.model import QuantumModel
from hqrnn.data_handler.digits import DigitDataHandler
from hqrnn.visualizer.digits import DigitVisualizer
from hqrnn.utils.checkpoint import CheckpointManager
from hqrnn.trainers.autodiff import Trainer_Autodiff
from hqrnn.utils.seed import set_seed

# Import CNN utilities
from flax import linen as nn
from flax.training import train_state
import optax

# 7x7 CNN Model

class CNN7x7(nn.Module):
    """CNN that works directly on 7x7 images"""
    @nn.compact
    def __call__(self, x):
        # Input: (batch, 7, 7, 1)
        # Add padding to make it 8x8 for cleaner pooling
        x = jnp.pad(x, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')
        # Now: (batch, 8, 8, 1)
        
        x = nn.Conv(features=32, kernel_size=(3, 3), padding='SAME')(x)
        x = nn.relu(x)
        x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
        # Now: (batch, 4, 4, 32)
        
        x = nn.Conv(features=64, kernel_size=(3, 3), padding='SAME')(x)
        x = nn.relu(x)
        x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
        # Now: (batch, 2, 2, 64)
        
        x = x.reshape((x.shape[0], -1))  # Flatten
        x = nn.Dense(features=128)(x)
        x = nn.relu(x)
        x = nn.Dense(features=1)(x)
        return x

def create_cnn_state(params):
    model = CNN7x7()
    tx = optax.adam(0.001)
    return train_state.TrainState.create(apply_fn=model.apply, params={'params': params}, tx=tx)

@jax.jit
def predict_probabilities(state, images):
    logits = state.apply_fn(state.params, images).squeeze(axis=-1)
    return jax.nn.sigmoid(logits)

def train_cnn(train_images, train_labels, val_images, val_labels, epochs=50, batch_size=32):
    """Train 7x7 CNN classifier"""
    print("Training 7x7 CNN classifier...")
    
    # Initialize model
    model = CNN7x7()
    key = random.PRNGKey(42)
    dummy_input = jnp.ones((1, 7, 7, 1))
    params = model.init(key, dummy_input)
    
    tx = optax.adam(0.001)
    state = train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)
    
    @jax.jit
    def train_step(state, batch_images, batch_labels):
        def loss_fn(params):
            logits = state.apply_fn(params, batch_images).squeeze(axis=-1)
            loss = optax.sigmoid_binary_cross_entropy(logits, batch_labels.astype(jnp.float32)).mean()
            return loss
        
        loss, grads = jax.value_and_grad(loss_fn)(state.params)
        state = state.apply_gradients(grads=grads)
        return state, loss
    
    # Training loop
    n_train = len(train_images)
    for epoch in range(epochs):
        key, subkey = random.split(key)
        perm = random.permutation(subkey, n_train)
        
        epoch_loss = 0.0
        n_batches = 0
        
        for i in range(0, n_train, batch_size):
            batch_idx = perm[i:i+batch_size]
            batch_images = train_images[batch_idx]
            batch_labels = train_labels[batch_idx]
            
            state, loss = train_step(state, batch_images, batch_labels)
            epoch_loss += loss
            n_batches += 1
        
        if (epoch + 1) % 10 == 0:
            # Validation accuracy
            val_probs = predict_probabilities(state, val_images)
            val_preds = (val_probs > 0.5).astype(jnp.int32)
            val_acc = jnp.mean(val_preds == val_labels) * 100
            print(f"Epoch {epoch+1}/{epochs}, Loss: {epoch_loss/n_batches:.4f}, Val Acc: {val_acc:.2f}%")
    
    return state

def load_or_train_cnn(cnn_path, train_data_path):
    """Load existing CNN or train new one"""
    if cnn_path.exists():
        print(f"Loading existing CNN from {cnn_path}")
        with open(cnn_path, 'rb') as f:
            data = pickle.load(f)
        return create_cnn_state(data['params'])
    
    # Train new CNN
    print("Training new CNN...")
    df = pd.read_csv(train_data_path)
    images = df.iloc[:, 1:].values.reshape(-1, 7, 7).astype(np.float32)
    labels = df.iloc[:, 0].values.astype(np.int32)
    
    # Split train/val
    n_train = int(len(images) * 0.8)
    train_images = images[:n_train]
    train_labels = labels[:n_train]
    val_images = images[n_train:]
    val_labels = labels[n_train:]
    
    # Add channel dimension
    train_images = train_images[..., None]
    val_images = val_images[..., None]
    
    cnn_state = train_cnn(train_images, train_labels, val_images, val_labels)
    
    # Save CNN
    cnn_path.parent.mkdir(parents=True, exist_ok=True)
    with open(cnn_path, 'wb') as f:
        pickle.dump({'params': cnn_state.params['params']}, f)
    print(f"CNN saved to {cnn_path}")
    
    return cnn_state

# JAX FID

def calculate_fid_jax(real_images, gen_images):
    """
    Calculate FID using JAX (simplified version)
    real_images, gen_images: (N, 7, 7) arrays
    """
    from scipy import linalg
    
    # Flatten images
    real_flat = real_images.reshape(len(real_images), -1)
    gen_flat = gen_images.reshape(len(gen_images), -1)
    
    # Calculate statistics
    mu_real = np.mean(real_flat, axis=0)
    mu_gen = np.mean(gen_flat, axis=0)
    
    sigma_real = np.cov(real_flat, rowvar=False)
    sigma_gen = np.cov(gen_flat, rowvar=False)
    
    # Calculate FID
    diff = mu_real - mu_gen
    
    # Product might be almost singular
    covmean, _ = linalg.sqrtm(sigma_real.dot(sigma_gen), disp=False)
    if not np.isfinite(covmean).all():
        offset = np.eye(sigma_real.shape[0]) * 1e-6
        covmean = linalg.sqrtm((sigma_real + offset).dot(sigma_gen + offset))
    
    # Numerical error might give slight imaginary component
    if np.iscomplexobj(covmean):
        if not np.allclose(np.diagonal(covmean).imag, 0, atol=1e-3):
            m = np.max(np.abs(covmean.imag))
            print(f"Warning: Imaginary component {m} in FID calculation")
        covmean = covmean.real
    
    fid = diff.dot(diff) + np.trace(sigma_real) + np.trace(sigma_gen) - 2 * np.trace(covmean)
    
    return float(fid)

# Generation and Evaluation Functions

def generate_digits(params, q_model, config, n_samples=400, digit_label=0, seed_start=1):
    """Generate n_samples of digit_label with varying seeds"""
    mdl = config.model_cfg
    D, T = mdl.n_D, mdl.seq_len
    powers = 2 ** jnp.arange(D - 1, -1, -1)
    
    @partial(jax.jit, static_argnames=['label_idx'])
    def _gen_one(key, label_idx):
        h = jnp.zeros(2**mdl.n_H, dtype=jnp.complex64).at[0].set(1.0)
        cur = jnp.zeros(D, dtype=jnp.float32)
        
        def _sample(params, h_state, x_row, label_idx, key):
            probs = q_model.circuit_for_probs(params, h_state, x_row, label_idx)
            probs = jnp.clip(probs, 0.0, 1.0) / (jnp.sum(jnp.clip(probs, 0.0, 1.0)) + 1e-9)
            measured_int = random.categorical(key, jnp.log(probs))
            bits = (jnp.floor_divide(measured_int, powers) % 2).astype(jnp.int32)
            return bits, measured_int
        
        def body(t, state):
            h_state, x_t, key, rows = state
            key, subkey = random.split(key)
            bits, idx = _sample(params, h_state, x_t, label_idx, subkey)
            full_state = q_model.circuit_for_state(params, h_state, x_t, label_idx)
            psi = jnp.reshape(full_state, (2**mdl.n_H, 2**D))
            h_unnorm = psi[:, idx]
            h_norm = jnp.linalg.norm(h_unnorm)
            h_next = jnp.where(h_norm > 1e-9, h_unnorm / h_norm, h_state)
            return (h_next, bits.astype(jnp.float32), key, rows.at[t].set(bits))
        
        init = (h, cur, key, jnp.zeros((T, D), dtype=jnp.int32))
        _, _, _, rows = lax.fori_loop(0, T, body, init)
        return rows
    
    samples = []
    for i in tqdm(range(n_samples), desc=f"Gen digit {digit_label}", leave=False):
        key = random.PRNGKey(seed_start + i)
        samples.append(np.array(_gen_one(key, digit_label)))
    
    return np.array(samples)

def evaluate_cnn(cnn_state, samples_7x7, true_labels):
    """Evaluate with 7x7 CNN"""
    images = samples_7x7[..., None]  # Add channel dimension
    probs = predict_probabilities(cnn_state, images)
    preds = (probs > 0.5).astype(jnp.int32)
    acc = jnp.mean(preds == true_labels) * 100
    return float(acc)

# Experiment Runner

def run_single_experiment(exp_name, config_fn, base_dir):
    """Run single training experiment"""
    print(f"\n{'='*60}\n{exp_name}\n{'='*60}")
    
    config = config_fn()
    exp_dir = base_dir / exp_name
    config.checkpoint_cfg.base_checkpoint_dir = str(exp_dir)
    set_seed(42)
    
    q_model = QuantumModel(config=config)
    data_handler = DigitDataHandler(config=config)
    visualizer = DigitVisualizer(config=config, q_model=q_model)
    ckpt_manager = CheckpointManager(config=config)
    
    # Train
    print("Training...")
    trainer = Trainer_Autodiff(config, q_model, data_handler, visualizer, ckpt_manager)
    final_params, final_state, loss_history = trainer.run()
    
    print(f"{exp_name} training completed")
    return exp_dir

def evaluate_checkpoint(exp_dir, tag, cnn_state, real_samples, config):
    """Evaluate a single checkpoint"""
    print(f"\nEvaluating {exp_dir.name} - {tag}...")
    
    # Load checkpoint
    ckpt_manager = CheckpointManager(config)
    ckpt_manager.exp_dir = exp_dir
    ckpt_manager.ckpt_dir = exp_dir / "ckpt"
    
    loaded = ckpt_manager.load_checkpoint(tag)
    if loaded is None:
        print(f"{tag} checkpoint not found")
        return None
    
    params, _, _, _, _, _ = loaded
    
    # Setup model
    q_model = QuantumModel(config=config)
    
    # Generate samples
    gen0 = generate_digits(params, q_model, config, 400, 0, seed_start=1)
    gen1 = generate_digits(params, q_model, config, 400, 1, seed_start=1)
    all_gen = np.concatenate([gen0, gen1], axis=0)
    all_labels = np.array([0]*400 + [1]*400)
    
    # Save generated samples
    csv_path = exp_dir / f'generated_{tag}.csv'
    df = pd.DataFrame(all_gen.reshape(len(all_gen), 49), columns=[f'p_{i}' for i in range(49)])
    df.insert(0, 'label', all_labels)
    df.to_csv(csv_path, index=False)
    print(f"  Saved: {csv_path}")
    
    # CNN accuracy
    acc = evaluate_cnn(cnn_state, all_gen, all_labels)
    print(f"  CNN Accuracy: {acc:.2f}%")
    
    # FID
    fid = calculate_fid_jax(real_samples, all_gen)
    print(f"  FID: {fid:.4f}")
    
    return {
        'accuracy': acc,
        'fid': fid
    }

# Main Experiment

if __name__ == '__main__':
    print("="*80)
    print("Comprehensive Experiment: 8 Training Conditions")
    print("="*80)
    
    BASE_DIR = Path("runs/model/3/1113")
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    
    # Prepare CNN and real samples
    CNN_PATH = BASE_DIR / "cnn_7x7.pkl"
    REAL_DATA_PATH = Path("https://raw.githubusercontent.com/w-jiwonchoi/HQRNN_dataset/main/model_3_digit.csv")
    
    # For real samples, load from dataset
    print("\nPreparing real samples for FID...")
    df = pd.read_csv("https://raw.githubusercontent.com/w-jiwonchoi/HQRNN_dataset/main/model_3_digit.csv")
    real_images = df.iloc[:, 1:].values.reshape(-1, 7, 7).astype(np.float32)
    real_labels = df.iloc[:, 0].values
    
    # Sample 800 real images (400 of each digit)
    real_0 = real_images[real_labels == 0][:400]
    real_1 = real_images[real_labels == 1][:400]
    real_samples = np.concatenate([real_0, real_1], axis=0)
    
    print(f"Using {len(real_samples)} real samples for FID calculation")
    
    # Train or load CNN
    cnn_state = load_or_train_cnn(CNN_PATH, "https://raw.githubusercontent.com/w-jiwonchoi/HQRNN_dataset/main/model_3_digit.csv")
    
    # Define 8 experiments
    experiments = [
        ("MMD_FFF_TF", lambda: create_config('mmd', True, 'teacher_forcing')),
        ("MMD_Cos_TF", lambda: create_config('mmd', False, 'teacher_forcing')),
        ("MMD_FFF_Au", lambda: create_config('mmd', True, 'autoregressive')),
        ("MMD_Cos_Au", lambda: create_config('mmd', False, 'autoregressive')),
        ("NLL_FFF_TF", lambda: create_config('nll', True, 'teacher_forcing')),
        ("NLL_Cos_TF", lambda: create_config('nll', False, 'teacher_forcing')),
        ("NLL_FFF_Au", lambda: create_config('nll', True, 'autoregressive')),
        ("NLL_Cos_Au", lambda: create_config('nll', False, 'autoregressive')),
    ]
    
    def create_config(loss_fn, use_fff, learning_mode):
        c = Config(model=3)
        c.exp_cfg = ExperimentConfig(loss_fn, 'soft', learning_mode)
        c.scheduler_toggle_cfg.use_complex_scheduler = use_fff
        return c
    
    # Run all experiments
    all_results = {}
    
    for exp_name, config_fn in experiments:
        exp_dir = run_single_experiment(exp_name, config_fn, BASE_DIR)
        
        # Evaluate both checkpoints
        config = config_fn()
        
        results = {}
        for tag in ['best', 'last' if not config.scheduler_toggle_cfg.use_complex_scheduler else 'final']:
            res = evaluate_checkpoint(exp_dir, tag, cnn_state, real_samples, config)
            if res:
                results[tag] = res
        
        all_results[exp_name] = results
        
        # Save intermediate results
        with open(BASE_DIR / 'results_progress.json', 'w') as f:
            json.dump(all_results, f, indent=2)
    
    # Generate Plots
    
    print("\n" + "="*80)
    print("Generating plots...")
    print("="*80)
    
    exp_names = [name for name, _ in experiments]
    
    # Extract results
    best_acc = [all_results[name]['best']['accuracy'] if 'best' in all_results[name] else 0 for name in exp_names]
    last_acc = [all_results[name].get('last', all_results[name].get('final', {})).get('accuracy', 0) for name in exp_names]
    best_fid = [all_results[name]['best']['fid'] if 'best' in all_results[name] else 0 for name in exp_names]
    last_fid = [all_results[name].get('last', all_results[name].get('final', {})).get('fid', 0) for name in exp_names]
    
    # Plot settings
    x = np.arange(len(exp_names))
    width = 0.6
    
    # Plot 1: Best CNN Accuracy
    fig, ax = plt.subplots(figsize=(14, 6))
    bars = ax.bar(x, best_acc, width, color='steelblue', alpha=0.8)
    ax.set_ylabel('CNN Accuracy (%)', fontsize=12)
    ax.set_title('Best Checkpoint: CNN Accuracy', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(exp_names, rotation=45, ha='right')
    ax.grid(axis='y', alpha=0.3)
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.1f}%', ha='center', va='bottom', fontsize=10)
    plt.tight_layout()
    plt.savefig(BASE_DIR / 'plot1_best_cnn_accuracy.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("✓ Plot 1 saved")
    
    # Plot 2: Last/Final CNN Accuracy
    fig, ax = plt.subplots(figsize=(14, 6))
    bars = ax.bar(x, last_acc, width, color='coral', alpha=0.8)
    ax.set_ylabel('CNN Accuracy (%)', fontsize=12)
    ax.set_title('Last/Final Checkpoint: CNN Accuracy', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(exp_names, rotation=45, ha='right')
    ax.grid(axis='y', alpha=0.3)
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.1f}%', ha='center', va='bottom', fontsize=10)
    plt.tight_layout()
    plt.savefig(BASE_DIR / 'plot2_last_cnn_accuracy.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("✓ Plot 2 saved")
    
    # Plot 3: Best FID
    fig, ax = plt.subplots(figsize=(14, 6))
    bars = ax.bar(x, best_fid, width, color='mediumseagreen', alpha=0.8)
    ax.set_ylabel('FID Score', fontsize=12)
    ax.set_title('Best Checkpoint: FID Score (Lower is Better)', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(exp_names, rotation=45, ha='right')
    ax.grid(axis='y', alpha=0.3)
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.2f}', ha='center', va='bottom', fontsize=10)
    plt.tight_layout()
    plt.savefig(BASE_DIR / 'plot3_best_fid.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("✓ Plot 3 saved")
    
    # Plot 4: Last/Final FID
    fig, ax = plt.subplots(figsize=(14, 6))
    bars = ax.bar(x, last_fid, width, color='mediumpurple', alpha=0.8)
    ax.set_ylabel('FID Score', fontsize=12)
    ax.set_title('Last/Final Checkpoint: FID Score (Lower is Better)', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(exp_names, rotation=45, ha='right')
    ax.grid(axis='y', alpha=0.3)
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.2f}', ha='center', va='bottom', fontsize=10)
    plt.tight_layout()
    plt.savefig(BASE_DIR / 'plot4_last_fid.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("✓ Plot 4 saved")
    
    # Save Summary CSV
    
    summary_data = []
    for exp_name in exp_names:
        row = {'Experiment': exp_name}
        if 'best' in all_results[exp_name]:
            row['Best_CNN_Acc'] = all_results[exp_name]['best']['accuracy']
            row['Best_FID'] = all_results[exp_name]['best']['fid']
        else:
            row['Best_CNN_Acc'] = None
            row['Best_FID'] = None
        
        last_key = 'last' if 'last' in all_results[exp_name] else 'final'
        if last_key in all_results[exp_name]:
            row['Last_CNN_Acc'] = all_results[exp_name][last_key]['accuracy']
            row['Last_FID'] = all_results[exp_name][last_key]['fid']
        else:
            row['Last_CNN_Acc'] = None
            row['Last_FID'] = None
        
        summary_data.append(row)
    
    summary_df = pd.DataFrame(summary_data)
    summary_df.to_csv(BASE_DIR / 'summary_results.csv', index=False)
    print("✓ Summary CSV saved")
    
    # Save detailed JSON
    with open(BASE_DIR / 'detailed_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print("\n" + "="*80)
    print("All experiments completed!")
    print(f"Results saved in: {BASE_DIR}")
    print("="*80)
    
    # Print summary table
    print("\nSummary Results:")
    print(summary_df.to_string(index=False))