from jax import random
import os
os.environ['JAX_PLATFORMS'] = 'cuda:2'

from hqrnn.config.base import Config, ExperimentConfig
from hqrnn.quantum.model import QuantumModel
from hqrnn.data_handler.digits import DigitDataHandler
from hqrnn.visualizer.digits import DigitVisualizer
from hqrnn.utils.checkpoint import CheckpointManager
from hqrnn.trainers.autodiff import Trainer_Autodiff
from hqrnn.utils.seed import set_seed, get_key
from hqrnn.utils.plotting import save_loss_plot

import json
import numpy as np
import pandas as pd
import jax
import jax.numpy as jnp
from pathlib import Path
from tqdm import tqdm
from functools import partial
import pickle
import matplotlib.pyplot as plt
from scipy import linalg

# Import CNN utilities
from flax import linen as nn
from flax.training import train_state
import optax

# CNN Models


class CNN7x7_VeryWeak(nn.Module):
    dropout_rate: float = 0.5
    
    @nn.compact
    def __call__(self, x, training: bool = True):
        x = jnp.pad(x, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')
        x = nn.Conv(features=8, kernel_size=(3, 3), padding='SAME')(x)
        x = nn.relu(x)
        x = nn.Dropout(rate=self.dropout_rate, deterministic=not training)(x)
        x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
        
        x = nn.Conv(features=16, kernel_size=(3, 3), padding='SAME')(x)
        x = nn.relu(x)
        x = nn.Dropout(rate=self.dropout_rate, deterministic=not training)(x)
        x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
        
        x = x.reshape((x.shape[0], -1))
        x = nn.Dense(features=32)(x)
        x = nn.relu(x)
        x = nn.Dropout(rate=self.dropout_rate, deterministic=not training)(x)
        x = nn.Dense(features=1)(x)
        return x

class CNN7x7_Strong(nn.Module):
    @nn.compact
    def __call__(self, x, training: bool = False):
        x = jnp.pad(x, ((0, 0), (0, 1), (0, 1), (0, 0)), mode='constant')
        x = nn.Conv(features=32, kernel_size=(3, 3), padding='SAME')(x)
        x = nn.relu(x)
        x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
        x = nn.Conv(features=64, kernel_size=(3, 3), padding='SAME')(x)
        x = nn.relu(x)
        x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
        x = x.reshape((x.shape[0], -1))
        x = nn.Dense(features=128)(x)
        x = nn.relu(x)
        x = nn.Dense(features=1)(x)
        return x

def create_cnn_state(params, model_type='strong'):
    if model_type == 'weak':
        model = CNN7x7_VeryWeak()
    else:
        model = CNN7x7_Strong()
    tx = optax.adam(0.001)
    return train_state.TrainState.create(apply_fn=model.apply, params={'params': params}, tx=tx)

def predict_probabilities(state, images, model_type='strong'):
    logits = state.apply_fn(state.params, images, training=False).squeeze(axis=-1)
    return jax.nn.sigmoid(logits)

def evaluate_cnn(cnn_state, samples_7x7, true_labels, model_type='strong'):
    images = samples_7x7[..., None]
    probs = predict_probabilities(cnn_state, images, model_type)
    preds = (probs > 0.5).astype(jnp.int32)
    acc = jnp.mean(preds == true_labels) * 100
    return float(acc)

def train_cnn(train_images, train_labels, val_images, val_labels, 
              epochs=50, batch_size=32, learning_rate=0.001, 
              model_type='strong', desc=""):
    print(f"Training 7x7 CNN classifier ({desc})...")
    
    if model_type == 'weak':
        model = CNN7x7_VeryWeak()
    else:
        model = CNN7x7_Strong()
        
    key = random.PRNGKey(42)
    dummy_input = jnp.ones((1, 7, 7, 1))
    params = model.init(key, dummy_input, training=True)
    
    tx = optax.adam(learning_rate)
    state = train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)
    
    @jax.jit
    def train_step(state, batch_images, batch_labels, key):
        def loss_fn(params):
            if model_type == 'weak':
                logits = state.apply_fn(params, batch_images, training=True, rngs={'dropout': key}).squeeze(axis=-1)
            else:
                logits = state.apply_fn(params, batch_images, training=True).squeeze(axis=-1)
            loss = optax.sigmoid_binary_cross_entropy(logits, batch_labels.astype(jnp.float32)).mean()
            return loss
        
        loss, grads = jax.value_and_grad(loss_fn)(state.params)
        state = state.apply_gradients(grads=grads)
        return state, loss
    
    n_train = len(train_images)
    for epoch in range(epochs):
        key, subkey = random.split(key)
        perm = random.permutation(subkey, n_train)
        
        epoch_loss = 0.0
        n_batches = 0
        
        for i in range(0, n_train, batch_size):
            batch_idx = perm[i:i+batch_size]
            batch_images = train_images[batch_idx]
            batch_labels = train_labels[batch_idx]
            
            key, dropout_key = random.split(key)
            state, loss = train_step(state, batch_images, batch_labels, dropout_key)
            epoch_loss += loss
            n_batches += 1
        
        if (epoch + 1) % 5 == 0 or epoch == 0:
            val_probs = predict_probabilities(state, val_images, model_type)
            val_preds = (val_probs > 0.5).astype(jnp.int32)
            val_acc = jnp.mean(val_preds == val_labels) * 100
            print(f"Epoch {epoch+1}/{epochs}, Loss: {epoch_loss/n_batches:.4f}, Val Acc: {val_acc:.2f}%")
    
    return state

def load_or_train_cnn(cnn_path, train_data_path, epochs, learning_rate, model_type, desc):
    if cnn_path.exists():
        print(f"Loading existing CNN from {cnn_path}")
        with open(cnn_path, 'rb') as f:
            data = pickle.load(f)
        return create_cnn_state(data['params'], model_type=model_type)
    
    print(f"Training new CNN ({desc})...")
    df = pd.read_csv(train_data_path)
    images = df.iloc[:, 1:].values.reshape(-1, 7, 7).astype(np.float32)
    labels = df.iloc[:, 0].values.astype(np.int32)
    
    n_train = int(len(images) * 0.8)
    train_images = images[:n_train][..., None]
    train_labels = labels[:n_train]
    val_images = images[n_train:][..., None]
    val_labels = labels[n_train:]
    
    cnn_state = train_cnn(train_images, train_labels, val_images, val_labels, 
                          epochs=epochs, learning_rate=learning_rate,
                          model_type=model_type, desc=desc)
    
    cnn_path.parent.mkdir(parents=True, exist_ok=True)
    with open(cnn_path, 'wb') as f:
        pickle.dump({'params': cnn_state.params['params']}, f)
    print(f"CNN saved to {cnn_path}")
    
    return cnn_state

# C2ST

def compute_c2st(real_images, fake_images, n_splits=5):
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import cross_val_score
    
    print("  Computing C2ST...")
    
    X_real = real_images.reshape(len(real_images), -1)
    X_fake = fake_images.reshape(len(fake_images), -1)
    X = np.concatenate([X_real, X_fake], axis=0)
    y = np.array([1]*len(real_images) + [0]*len(fake_images))
    
    clf = LogisticRegression(penalty='l2', C=0.01, max_iter=500, random_state=42, solver='lbfgs')
    scores = cross_val_score(clf, X, y, cv=n_splits, scoring='accuracy')
    
    c2st_mean = scores.mean() * 100
    c2st_std = scores.std() * 100
    
    print(f"  C2ST: {c2st_mean:.2f}% ± {c2st_std:.2f}%")
    
    return float(c2st_mean)

# Generation Functions

def generate_digits(params, q_model, config, n_samples=5000, digit_label=0, seed_start=0):
    mdl = config.model_cfg
    D, T = mdl.n_D, mdl.seq_len
    powers = 2 ** jnp.arange(D - 1, -1, -1)
    
    @partial(jax.jit, static_argnames=['label_idx'])
    def _gen_one(key, label_idx):
        h = jnp.zeros(2**mdl.n_H, dtype=jnp.complex64).at[0].set(1.0)
        cur = jnp.zeros(D, dtype=jnp.float32)
        
        def _sample(params, h_state, x_row, label_idx, key):
            probs = q_model.circuit_for_probs(params, h_state, x_row, label_idx)
            probs = jnp.clip(probs, 0.0, 1.0) / (jnp.sum(jnp.clip(probs, 0.0, 1.0)) + 1e-9)
            measured_int = random.categorical(key, jnp.log(probs))
            bits = (jnp.floor_divide(measured_int, powers) % 2).astype(jnp.int32)
            return bits, measured_int
        
        def body(t, state):
            h_state, x_t, key, rows = state
            key, subkey = random.split(key)
            bits, idx = _sample(params, h_state, x_t, label_idx, subkey)
            full_state = q_model.circuit_for_state(params, h_state, x_t, label_idx)
            psi = jnp.reshape(full_state, (2**mdl.n_H, 2**D))
            h_unnorm = psi[:, idx]
            h_norm = jnp.linalg.norm(h_unnorm)
            h_next = jnp.where(h_norm > 1e-9, h_unnorm / h_norm, h_state)
            return (h_next, bits.astype(jnp.float32), key, rows.at[t].set(bits))
        
        init = (h, cur, key, jnp.zeros((T, D), dtype=jnp.int32))
        _, _, _, rows = jax.lax.fori_loop(0, T, body, init)
        return rows
    
    samples = []
    for i in tqdm(range(n_samples), desc=f"Gen digit {digit_label}", leave=False):
        key = random.PRNGKey(seed_start + i)
        samples.append(np.array(_gen_one(key, digit_label)))
    
    return np.array(samples)

# Checkpoint Loading

def load_checkpoint_directly(ckpt_path):
    with open(ckpt_path, 'rb') as f:
        data = pickle.load(f)
    params = data['params']
    params = jax.tree_util.tree_map(jnp.array, params)
    return params

def find_checkpoint_path(base_path, checkpoint_name):
    for subdir in base_path.glob("Q*"):
        if subdir.is_dir():
            ckpt_dir = subdir / "ckpt"
            if ckpt_dir.exists():
                ckpt_path = ckpt_dir / f"{checkpoint_name}.pkl"
                if ckpt_path.exists():
                    return ckpt_path
    return None

# Evaluation Metrics

def calculate_binary_fid(real_images, gen_images, threshold=0.5):
    real_binary = (real_images > threshold).astype(np.float32)
    gen_binary = (gen_images > threshold).astype(np.float32)
    
    real_flat = real_binary.reshape(len(real_binary), -1)
    gen_flat = gen_binary.reshape(len(gen_binary), -1)
    
    mu_real = np.mean(real_flat, axis=0)
    mu_gen = np.mean(gen_flat, axis=0)
    
    sigma_real = np.cov(real_flat, rowvar=False)
    sigma_gen = np.cov(gen_flat, rowvar=False)
    
    diff = mu_real - mu_gen
    
    eps = 1e-6
    sigma_real += np.eye(sigma_real.shape[0]) * eps
    sigma_gen += np.eye(sigma_gen.shape[0]) * eps
    
    covmean, _ = linalg.sqrtm(sigma_real.dot(sigma_gen), disp=False)
    
    if np.iscomplexobj(covmean):
        covmean = covmean.real
    
    fid = diff.dot(diff) + np.trace(sigma_real) + np.trace(sigma_gen) - 2 * np.trace(covmean)
    
    return float(fid)

def calculate_pixel_mean_diff(real_images, gen_images):
    real_mean = np.mean(real_images, axis=0).flatten()
    gen_mean = np.mean(gen_images, axis=0).flatten()
    diff = np.abs(real_mean - gen_mean).mean()
    return float(diff)

def calculate_sparsity_diff(real_images, gen_images, threshold=0.5):
    real_sparsity = np.mean(real_images > threshold, axis=(1, 2))
    gen_sparsity = np.mean(gen_images > threshold, axis=(1, 2))
    
    real_hist, _ = np.histogram(real_sparsity, bins=20, range=(0, 1), density=True)
    gen_hist, _ = np.histogram(gen_sparsity, bins=20, range=(0, 1), density=True)
    
    real_hist = real_hist + 1e-10
    gen_hist = gen_hist + 1e-10
    real_hist = real_hist / real_hist.sum()
    gen_hist = gen_hist / gen_hist.sum()
    
    kl_div = np.sum(real_hist * np.log(real_hist / gen_hist))
    return float(kl_div)

def calculate_correlation_diff(real_images, gen_images):
    real_flat = real_images.reshape(len(real_images), -1)
    gen_flat = gen_images.reshape(len(gen_images), -1)
    
    real_std = np.std(real_flat, axis=0)
    gen_std = np.std(gen_flat, axis=0)
    
    valid_mask = (real_std > 1e-6) & (gen_std > 1e-6)
    n_valid = np.sum(valid_mask)
    
    if n_valid < 2:
        print(f"    Warning: Only {n_valid} pixels with variance, returning 0")
        return 0.0
    
    print(f"    Using {n_valid}/{len(valid_mask)} pixels with non-zero variance")
    
    real_filtered = real_flat[:, valid_mask]
    gen_filtered = gen_flat[:, valid_mask]
    
    real_corr = np.corrcoef(real_filtered.T)
    gen_corr = np.corrcoef(gen_filtered.T)
    
    diff = np.linalg.norm(real_corr - gen_corr, 'fro')
    
    return float(diff)

def calculate_hamming_distance(real_images, gen_images, threshold=0.5):
    real_binary = (real_images > threshold).astype(np.float32)
    gen_binary = (gen_images > threshold).astype(np.float32)
    
    real_flat = real_binary.reshape(len(real_binary), -1)
    gen_flat = gen_binary.reshape(len(gen_binary), -1)
    
    n_real = len(real_flat)
    n_gen = len(gen_flat)
    n_pairs = min(1000, n_real * n_gen)
    
    distances = []
    for _ in range(n_pairs):
        i = np.random.choice(n_real)
        j = np.random.choice(n_gen)
        dist = np.mean(real_flat[i] != gen_flat[j])
        distances.append(dist)
    
    return float(np.mean(distances))

def remove_duplicates_keep_target(samples, confidences, target_count):
    n_samples = len(samples)
    sample_tuples = [tuple(s.flatten()) for s in samples]
    
    first_occurrence = {}
    duplicates = []
    
    for i, (sample_tuple, conf) in enumerate(zip(sample_tuples, confidences)):
        if sample_tuple not in first_occurrence:
            first_occurrence[sample_tuple] = i
        else:
            duplicates.append((i, conf, sample_tuple))
    
    duplicates.sort(key=lambda x: x[1])
    keep_indices = set(range(n_samples))
    
    for idx, _, _ in duplicates:
        if len(keep_indices) <= target_count:
            break
        keep_indices.remove(idx)
    
    if len(keep_indices) > target_count:
        remaining = [(i, confidences[i]) for i in keep_indices]
        remaining.sort(key=lambda x: x[1])
        
        n_to_remove = len(keep_indices) - target_count
        for i in range(n_to_remove):
            keep_indices.remove(remaining[i][0])
    
    return sorted(list(keep_indices))

# Evaluation Pipeline

def evaluate_checkpoint(exp_name, exp_path, cnn_selector, cnn_evaluator, real_samples_dict, config, output_dir):
    print(f"\n{'='*60}")
    print(f"Evaluating: {exp_name}")
    print(f"{'='*60}")
    
    q_model = QuantumModel(config=config)
    results = {}
    
    checkpoint_names = ['best', 'final']
    
    for ckpt_name in checkpoint_names:
        print(f"\n--- Checkpoint: {ckpt_name} ---")
        
        ckpt_path = find_checkpoint_path(exp_path, ckpt_name)
        if ckpt_path is None:
            print(f"Checkpoint '{ckpt_name}' not found")
            continue
        
        try:
            params = load_checkpoint_directly(ckpt_path)
            print(f"Checkpoint loaded")
        except Exception as e:
            print(f"Error loading checkpoint: {e}")
            continue
        
        print(f"  Generating 5000 samples for digit 0 and 1...")
        ckpt_hash = hash(f"{exp_name}_{ckpt_name}") % 50000
        gen0_all = generate_digits(params, q_model, config, 5000, 0, seed_start=ckpt_hash)
        gen1_all = generate_digits(params, q_model, config, 5000, 1, seed_start=ckpt_hash + 5000)
        
        print(f"  Calculating confidence scores (using weak CNN)...")
        gen0_images = gen0_all[..., None]
        gen1_images = gen1_all[..., None]
        
        probs0 = predict_probabilities(cnn_selector, gen0_images, model_type='weak')
        probs1 = predict_probabilities(cnn_selector, gen1_images, model_type='weak')
        
        confidence0 = 1 - np.array(probs0)
        confidence1 = np.array(probs1)
        
        n_top = 1000
        top_1000_indices_0 = np.argsort(confidence0)[-n_top:][::-1]
        top_1000_indices_1 = np.argsort(confidence1)[-n_top:][::-1]
        
        gen0_top1000 = gen0_all[top_1000_indices_0]
        gen1_top1000 = gen1_all[top_1000_indices_1]
        conf0_top1000 = confidence0[top_1000_indices_0]
        conf1_top1000 = confidence1[top_1000_indices_1]
        
        print(f"  Removing duplicates from digit-0 (target: 536)...")
        keep_indices_0 = remove_duplicates_keep_target(gen0_top1000, conf0_top1000, 536)
        gen0_selected = gen0_top1000[keep_indices_0]
        
        print(f"  Removing duplicates from digit-1 (target: 448)...")
        keep_indices_1 = remove_duplicates_keep_target(gen1_top1000, conf1_top1000, 448)
        gen1_selected = gen1_top1000[keep_indices_1]
        
        selected_gen = np.concatenate([gen0_selected, gen1_selected], axis=0)
        
        real_0 = real_samples_dict[0]
        real_1 = real_samples_dict[1]
        all_real = np.concatenate([real_0, real_1], axis=0)
        
        print(f"  [1/7] CNN Accuracy (All 10000)...")
        all_gen_images = np.concatenate([gen0_all, gen1_all], axis=0)
        all_gen_labels = np.array([0]*5000 + [1]*5000)
        acc = evaluate_cnn(cnn_evaluator, all_gen_images, all_gen_labels, model_type='strong')
        
        print(f"  [2/7] Binary FID...")
        binary_fid = calculate_binary_fid(all_real, selected_gen)
        
        print(f"  [3/7] C2ST (Real vs Fake)...")
        c2st_score = compute_c2st(all_real, selected_gen)
        
        print(f"  [4/7] Pixel-wise Mean...")
        pixel_mean = calculate_pixel_mean_diff(all_real, selected_gen)
        
        print(f"  [5/7] Sparsity Distribution...")
        sparsity = calculate_sparsity_diff(all_real, selected_gen)
        
        print(f"  [6/7] Pixel Correlation...")
        correlation = calculate_correlation_diff(all_real, selected_gen)
        
        print(f"  [7/7] Hamming Distance...")
        hamming = calculate_hamming_distance(all_real, selected_gen)
        
        results[ckpt_name] = {
            'cnn_accuracy_all': acc,
            'binary_fid': binary_fid,
            'c2st_accuracy': c2st_score,
            'pixel_mean_diff': pixel_mean,
            'sparsity_kl_div': sparsity,
            'correlation_frobenius': correlation,
            'hamming_distance': hamming
        }
        
        print(f"  ✓ Results: Acc={acc:.2f}%, BinFID={binary_fid:.4f}, C2ST={c2st_score:.2f}%")
    
    return results

# Main (Experiment 3)

if __name__ == '__main__':
    print("="*80)
    print("Experiment 3: mmd_lambda variations")
    print("="*80)
    
    # Set seed
    set_seed(42)
    
    # Experiment configurations
    MMD_LAMBDAS = [0.30, 0.35, 0.40, 0.45, 0.50]
    
    OUTPUT_DIR = Path("runs/model/3/1205/1205_exp3")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    # Load CNNs
    print("\n[1] Loading CNN classifiers...")
    CNN_SELECTOR_PATH = OUTPUT_DIR / "cnn_selector_veryweak.pkl"
    cnn_selector = load_or_train_cnn(
        CNN_SELECTOR_PATH, 
        "https://raw.githubusercontent.com/w-jiwonchoi/HQRNN_dataset/main/model_3_digit.csv",
        epochs=1, learning_rate=0.02, model_type='weak',
        desc="Very Weak CNN for sample selection"
    )
    
    CNN_EVALUATOR_PATH = OUTPUT_DIR / "cnn_evaluator_strong.pkl"
    cnn_evaluator = load_or_train_cnn(
        CNN_EVALUATOR_PATH,
        "https://raw.githubusercontent.com/w-jiwonchoi/HQRNN_dataset/main/model_3_digit.csv",
        epochs=100, learning_rate=0.001, model_type='strong',
        desc="Strong CNN for evaluation"
    )
    
    # Load real samples
    print("\n[2] Loading real samples...")
    df = pd.read_csv("https://raw.githubusercontent.com/w-jiwonchoi/HQRNN_dataset/main/model_3_digit.csv")
    real_images = df.iloc[:, 1:].values.reshape(-1, 7, 7).astype(np.float32)
    real_labels = df.iloc[:, 0].values
    real_0 = real_images[real_labels == 0]
    real_1 = real_images[real_labels == 1]
    real_samples_dict = {0: real_0, 1: real_1}
    
    all_results = {}
    
    # Run experiments
    for ml in MMD_LAMBDAS:
        exp_name = f"ML_{ml}"
        print(f"\n{'='*80}")
        print(f"Running: {exp_name}")
        print(f"{'='*80}")
        
        # Setup config
        config = Config(model=3)
        config.exp_cfg = ExperimentConfig(
            loss_function="mmd",
            collapse_type="soft",
            learning_mode="autoregressive"
        )
        config.loss_cfg.mmd_lambda = ml
        config.checkpoint_cfg.base_checkpoint_dir = str(OUTPUT_DIR / exp_name)
        
        # Train
        q_model = QuantumModel(config=config)
        data_handler = DigitDataHandler(config=config)
        visualizer = DigitVisualizer(config=config, q_model=q_model)
        ckpt_manager = CheckpointManager(config=config)
        
        trainer = Trainer_Autodiff(config, q_model, data_handler, visualizer, ckpt_manager)
        final_params, final_state, loss_history = trainer.run()
        
        # Evaluate
        exp_path = Path(config.checkpoint_cfg.base_checkpoint_dir)
        results = evaluate_checkpoint(exp_name, exp_path, cnn_selector, cnn_evaluator, 
                                      real_samples_dict, config, OUTPUT_DIR)
        all_results[exp_name] = results
    
    # Save results
    with open(OUTPUT_DIR / 'all_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    # Create plots
    metrics = [
        ('cnn_accuracy_all', 'CNN Accuracy'),
        ('binary_fid', 'Binary FID'),
        ('c2st_accuracy', 'C2ST Accuracy'),
        ('pixel_mean_diff', 'Pixel Mean Diff'),
        ('sparsity_kl_div', 'Sparsity KL'),
        ('correlation_frobenius', 'Correlation Frob'),
        ('hamming_distance', 'Hamming Distance')
    ]
    
    for metric_key, metric_name in metrics:
        for ckpt_type in ['best', 'final']:
            exp_names = list(all_results.keys())
            values = []
            for exp_name in exp_names:
                if ckpt_type in all_results[exp_name]:
                    values.append(all_results[exp_name][ckpt_type].get(metric_key, 0))
                else:
                    values.append(0)
            
            fig, ax = plt.subplots(figsize=(10, 6))
            x = np.arange(len(exp_names))
            bars = ax.bar(x, values, color='turquoise', edgecolor='black', alpha=0.8)
            
            ax.set_ylabel(metric_name, fontsize=12, fontweight='bold')
            ax.set_title(f'{ckpt_type.upper()}: {metric_name}', fontsize=14, fontweight='bold')
            ax.set_xticks(x)
            ax.set_xticklabels(exp_names, rotation=45, ha='right')
            ax.grid(axis='y', alpha=0.3)
            
            for bar, val in zip(bars, values):
                if val > 0:
                    height = bar.get_height()
                    ax.text(bar.get_x() + bar.get_width()/2., height,
                           f'{val:.2f}', ha='center', va='bottom', fontsize=9)
            
            plt.tight_layout()
            plt.savefig(OUTPUT_DIR / f'{metric_key}_{ckpt_type}.png', dpi=150)
            plt.close()
    
    print("\nExperiment 3 completed!")